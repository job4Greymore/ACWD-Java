package com.acwd.m1.IU11;

/**
 * Created by Benjamin on $(DATE)
 */
import java.util.ArrayList;

public class Accountant extends BusinessEmployee {

//    private int bonusBudget = 0;
//    private TechnicalLead tname;

    private TechnicalLead technicalLead;
    BusinessLead manager;



    public Accountant(String name)//should start with a bonus budget of 0 and no team they are officially supporting
    {
        super(name);
        BonusBudget = 0;
        technicalLead =null;


    }
    public TechnicalLead getTeamSupport()//should return a reference to the TechnicalLead that
    // this Accountant is currently supporting.If they have not been
    // assigned a TechnicalLeead null should be returned.
    {

        return technicalLead;//return reference that it is supporting Technical lead
    }
    public void supportTeam(TechnicalLead lead)

    //should call a reference to a Technical to be passed in and saved.
    // once this happens the Accountant's bonus should be updated to be the total of each
    // SoftwareEnginer's base salary that reports to that TechnicalLead plus 10% .

    // For Example , if the TechnicalLead supports 2 SoftwareEngineer,each with salary of 75000,
    // the Accountant's budget should be 150000 + 15000 for a total of 165000.

    {
        lead.support =        this;
        BonusBudget = lead.team.size()*75000*11/10;
        this.technicalLead = lead;


//        if (lead.team.size() == 0){
//            int i = 0;
//            SoftwareEngineer member = lead.team.get(i);
//            double myBonus = (member.getBaseSalary() + (member.getBaseSalary() * 0.1));
//            this.BonusBudget+=lead.team.size();
    }


    public boolean approveBonus(double bonus) {/* should take a suggested bonus amount and check if there is still
    enough room in the budget. If the bonus is greater then the remaning budget,false should be returned,otherwise true.
    if the accountant is not supporting any team false should be returned.*/
        double requestBonus = bonus;
        if (requestBonus <= getBonusBudget()) {
            return true;
        } else {
            System.out.println("Rejected because budget not sufficient ");
            return false;
        }

    }
    public String employeeStatus (){/* Should return a String representation of this Accountant that
     includes their ID, name, the size of their currently managed budget and the name of the
      TechnicalLead they are currently supporting. Example:
      "1 Kasey with a budget of 22500.0 is supporting Satya Nadella"  */
        return this.toString()+ " with the budget  of  "+ getBonusBudget()+ " is supporting "+ technicalLead.getName()+"\n";

    }
    public Employee getManager(){
        return this.manager;
    }
}

