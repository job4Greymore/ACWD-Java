package com.acwd.m1.IU11;

/**
 * Created by Benjamin on $(DATE)
 */
public abstract class BusinessEmployee extends Employee{
    public double BonusBudget;

    public BusinessEmployee(String name){

        super(name,50000);

    }
    public double getBonusBudget()//should establish a running tally of the remaning bonusBudget for the team
    // this employee supports.How that budget is determine will depend on which
    // type of business employee it is.
    {

        return BonusBudget;

    }
    public String employeesStatus()//should return a String representation of this BusinessEmployee that
    // includes their ID,name and size of their currently managed budget,Example:
    //"1" Kasey with a budget of 22500.0
    {
        return this.getId()+this.getName()+" with a budget of "+ BonusBudget;
    }
    public abstract Employee getManager();
}