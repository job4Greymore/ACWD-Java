package com.acwd.m1.IU11;

/**
 * Created by Benjamin on $(DATE)
 */

public abstract class Employee {


    private int id;
    private String name;
    private double baseSalary;
    private Employee manager;
    private int headCount ;
    double bonus;


    private Accountant accountantSupport;

    static int empId = 1;

    public int getId() //should return the employee's ID should be issued on behalf of the employee
    //at the time they constracted . The first ever employee should have an
    // ID of "1",the secound "2" and so on
    {
        return id;
    }

    public String getName() //should return employee's current name
    {
        return name;
    }

    public double getBaseSalary()//should return base salary
    {

        return baseSalary;
    }


    public void setManager(Employee manager){
        this.manager= manager;
    }

    public boolean equals(Employee other)//should return TRUE if the two employee ID's are same,FALSE otherwise
    {


        return (this.id == other.id) ?true : false;
    }
    public String toString()//should return a String representation of the employee that is a
    //// combination of thier id followed by thier name.eg"1 kasey"
    {
        return this.id + " " + this.name;
    }


    public Employee(String name, double baseSalary)//08
    {
        this.id = empId++;// call get id method to ,retrive private id
        this.name = name;//call getName method to retrive private name
        this.baseSalary = baseSalary;//call getBasesalary method ,retrive private base salary


    }

    public void setBaseSalary(double baseSalary) {
        this.baseSalary = baseSalary;
    }

    public int getHeadCount() {
        return headCount;
    }

    public void setHeadCount(int headCount) {
        this.headCount = headCount;
    }

    public Accountant getAccountantSupport() {

        return accountantSupport;
    }
    public abstract  String employeeStatus();//should return a string repesentation of the employee's current status
    // This will be for the every subclass of Employee
    public abstract Employee getManager() ;///should return a reference to the Employee object that represent
    //this employee's manager




}
