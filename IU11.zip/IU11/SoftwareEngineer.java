package com.acwd.m1.IU11;

/**
 * Created by Benjamin on $(DATE)
 */

public class SoftwareEngineer extends TechnicalEmployee {
    public boolean codeAccess;
    private int SuccessfulCheckIns;
    TechnicalLead manager;

    public SoftwareEngineer(String name)// should start without access to code and with 0 code check ins
    {
        super(name);
        setCodeAccess(true);
    }

    public boolean getCodeAccess() {


        return codeAccess;
    }

    public void setCodeAccess(boolean codeAccess)//should return the current count of how many times
    // this softwareEngineer has successfully checked in code privileges to either true or false
    {
        this.codeAccess = codeAccess;
    }


    public int getSuccessfulCheckIns()//should return the current count of how many times this Software Engineer has successfully
    // checked in code
    {
        return this.checkIns;
    }

    public boolean checkInCode()//should check if this software Engineer's manager approves of their check ins.if the
    // check in is approved their successful checkin count should be increased and the
    // method  should return True. if the manager does not approvethe check ind the
    // software engineer's codee access shold be changed to FALSE and the method should return FALSE
    {
        TechnicalLead manager = (TechnicalLead) this.getManager();
        if (manager.approveCheckIn(this)) {
            this.checkIns++;
            return true;
        } else {
            codeAccess = false;


            return false;
        }

    }
    public Employee getManager(){
        return this.manager;
    }
}
