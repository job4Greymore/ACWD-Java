package com.acwd.m1.IU11;

/**
 * Created by Benjamin on $(DATE)
 */
public abstract class TechnicalEmployee extends Employee //Extends refer to taking from employees class
{
    public int checkIns ;
    public TechnicalEmployee(String name)
    {
        super (name,75000);// super is super class>> Emplyees classs
    }
    public String employeeStatus()// should return a string representation of this TechnicalEmployee that includes
    //thier ID. name and hoe many successful check ins they have had.
    //                                    eg."1"Kasey has 10s uccessful check ins.
    {
        return this.getId() + " "+ this.getName() + " has "+ this.checkIns + " successful check ins";
    }
    public void setCheckIns(){
        checkIns++;
    }

}
