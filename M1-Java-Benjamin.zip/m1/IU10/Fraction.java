//package com.acwd.m1.IU10;
///**
// * Created by Benjamin on $(DATE)
// */
//public class Fraction {
//
//    private int numerator;
//    private int denominator;
//
//
//    public int getNumerator() {
//        return numerator;
//    }
//
//    public int getDenominator() {
//        return denominator;
//    }
//
//    public String toString() {
//        return getNumerator() + "/" + getDenominator();
//    }
//
//    public Fraction add(int n, int d, int n2, int d2) {
//
//
//        //generated the constructor via generate fucntion.
//        this.numerator = n;
//        this.denominator = d;
//        this.numerator = n2;
//        this.denominator = d2;
//        int d3 = d + d2;
//        int n3 = n + n2;
//
//        System.out.println("Numerator is : " + n);
//        System.out.println("Denominator is : " + d);
//        System.out.println("Your Fraction is : " + n + "/" + d);
//        System.out.println(" ");
//        System.out.println("Numerator is : " + n2);
//        System.out.println("Denominator is : " + d2);
//        System.out.println("Your Fraction is : " + n2 + "/" + d2);
//        System.out.println(" ");
//        System.out.println("Numerator is : " + n3);
//        System.out.println("Denominator is : " + d3);
//        System.out.println("Your Fraction is : " + n3 + "/" + d3);
//        System.out.println(" ");
//
//
//        /*if (d == 0) {
//            throw new IllegalArgumentException("Denominator has invalid output!"); // this is new take note how to use this.
//        } else if (d < 0) {
//            d = d * -1;
//            n = n * -1;
//        }*/
//        return add()
//
//    }
//
//    public Fraction subtract(int n, int d, int n2, int d2) {
//
//
//        //generated the constructor via generate fucntion.
//        this.numerator = n;
//        this.denominator = d;
//        this.numerator = n2;
//        this.denominator = d2;
//        int d3 = d - d2;
//        int n3 = n - n2;
//
//        System.out.println("Numerator is : " + n);
//        System.out.println("Denominator is : " + d);
//        System.out.println("Your Fraction is : " + n + "/" + d);
//        System.out.println(" ");
//        System.out.println("Numerator is : " + n2);
//        System.out.println("Denominator is : " + d2);
//        System.out.println("Your Fraction is : " + n2 + "/" + d2);
//        System.out.println(" ");
//        System.out.println("Numerator is : " + n3);
//        System.out.println("Denominator is : " + d3);
//        System.out.println("Your Fraction is : " + n3 + "/" + d3);
//        System.out.println(" ");
//
//
//        /*if (d == 0) {
//            throw new IllegalArgumentException("Denominator has invalid output!"); // this is new take note how to use this.
//        } else if (d < 0) {
//            d = d * -1;
//            n = n * -1;
//        }*/
//        return Fraction subtract(); //wrong.
//    }
//
//    public Fraction mulitply(int n, int d, int n2, int d2) {
//
//
//        //generated the constructor via generate fucntion.
//        this.numerator = n;
//        this.denominator = d;
//        this.numerator = n2;
//        this.denominator = d2;
//        int d3 = d * d2;
//        int n3 = n * n2;
//
//        System.out.println("Numerator is : " + n);
//        System.out.println("Denominator is : " + d);
//        System.out.println("Your Fraction is : " + n + "/" + d);
//        System.out.println(" ");
//        System.out.println("Numerator is : " + n2);
//        System.out.println("Denominator is : " + d2);
//        System.out.println("Your Fraction is : " + n2 + "/" + d2);
//        System.out.println(" ");
//        System.out.println("Numerator is : " + n3);
//        System.out.println("Denominator is : " + d3);
//        System.out.println("Your Fraction is : " + n3 + "/" + d3);
//        System.out.println(" ");
//
//
//        /*if (d == 0) {
//            throw new IllegalArgumentException("Denominator has invalid output!"); // this is new take note how to use this.
//        } else if (d < 0) {
//            d = d * -1;
//            n = n * -1;
//        }*/
//        return Fraction multiply(); //wrong.
//    }
//
//    public Fraction divide(int n, int d, int n2, int d2) {
//
//
//        //generated the constructor via generate fucntion.
//        this.numerator = n;
//        this.denominator = d;
//        this.numerator = n2;
//        this.denominator = d2;
//        int d3 = d / d2;
//        int n3 = n / n2;
//
//        System.out.println("Numerator is : " + n);
//        System.out.println("Denominator is : " + d);
//        System.out.println("Your Fraction is : " + n + "/" + d);
//        System.out.println(" ");
//        System.out.println("Numerator is : " + n2);
//        System.out.println("Denominator is : " + d2);
//        System.out.println("Your Fraction is : " + n2 + "/" + d2);
//        System.out.println(" ");
//        System.out.println("Numerator is : " + n3);
//        System.out.println("Denominator is : " + d3);
//        System.out.println("Your Fraction is : " + n3 + "/" + d3);
//        System.out.println(" ");
//
//
//        /*if (d == 0) {
//            throw new IllegalArgumentException("Denominator has invalid output!"); // this is new take note how to use this.
//        } else if (d < 0) {
//            d = d * -1;
//            n = n * -1;
//        }*/
//        return Fraction divide(); //wrong.
//    }
//
//    @Override
//    public boolean equals(other obj) {
//        return super.equals(other obj);
//    }
//
//    public void toLoewstTerm() {
//        public int gcd ( int num, int den){
//        }
//    }
//}
//

package com.acwd.m1.IU10;
public class Fraction {
    private int numerator;
    private int denominator;

    public int getNumerator() {
        return numerator;
    }

    public void setNumerator(int numerator) {
        this.numerator = numerator;
    }

    public int getDenominator() {
        return denominator;
    }

    public void setDenominator(int denominator) {
        this.denominator = denominator;
    }

    public Fraction(int num, int den) throws IllegalArgumentException {
        if(denominator == 0){
            throw new IllegalArgumentException();

        }else {
            this.numerator = num;
            this.denominator = den;
        }

    }

    public Fraction(int num) {
        this.numerator = num;
        this.denominator = 1;
    }

    public Fraction() {
        this.numerator = 0;
        this.denominator = 1;
    }

    public String toString() {
        return this.numerator + "/" + this.denominator;
    }

    public Fraction add (Fraction other) {
        int resultNr;
        int resultDr;

        resultNr = (this.numerator * other.denominator) + (other.numerator * this.denominator);
        resultDr = this.denominator * other.denominator;

        return new Fraction(resultNr, resultDr);

    }

    public Fraction subtract(Fraction other) {
        int resultNr;
        int resultDr;

        resultNr = (this.numerator * other.denominator) - (other.numerator * this.denominator);
        resultDr = this.denominator * other.denominator;

        return new Fraction(resultNr, resultDr);
    }

    public Fraction multiply(Fraction other) {
        int resultNr;
        int resultDr;

        resultNr = this.numerator * other.numerator;
        resultDr = this.denominator * other.denominator;

        return new Fraction(resultNr, resultDr);
    }

    public Fraction divide(Fraction other) {
        int resultNr;
        int resultDr;

        resultNr = this.numerator * other.denominator;
        resultDr = this.denominator * other.numerator;

        return new Fraction(resultNr, resultDr);
    }

    public int toLowestTerm(){
        int lt = 1;
        while ((this.numerator != 0) && (this.denominator != 0)) {
            lt = this.numerator % this.denominator; // lt = lowest term
            this.numerator = this.denominator;
            this.denominator = lt;

        }return toLowestTerm();

    }
    public int gdc(int num, int den){
        int gdc = 1;
        int reminder;
        while ((num != 0) && (den != 0)) {
            reminder = den % num;
            den = num;
            num =reminder;



        }return den;

    }
}

