package com.acwd.m1.IU10;
import java.util.*;

/**
 * Created by Benjamin on $(DATE)
 */
public class javatest {

    public static void main(String[] args) {

        operation();
    }
    private static String operator() {
        Scanner input = new Scanner(System.in);
        System.out.println("please input your value for a");
        String a = input.next();

        if (a.contains("+")) {

            System.out.println("this will be a Addition method");
            System.out.println("A +B ");
        } else if (a.contains("-")) {
            System.out.println("this will be a Subtractive method");
            System.out.println("A -B ");
        } else if (a.contains("*")) {
            System.out.println("this will be a Multiplication method");
            System.out.println("A *B ");
        } else if (a.contains("/")) {
            System.out.println("this will be a Division method");
            System.out.println("A /B ");
        } else if (a.contains("=")) {
            System.out.println("this will be an Equals to method");
            System.out.println("A =B ");
        } else {
            System.out.println("Your operator is invalid please try typing in the relevant inputs +,-,/,=,*");
        }
        return a;

    }
    public static void operation(){

        operator();


    }

}
