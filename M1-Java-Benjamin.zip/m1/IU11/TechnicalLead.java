package com.acwd.m1.IU11;

import java.util.ArrayList;

/**
 * Created by Benjamin on $(DATE)
 */
public class TechnicalLead extends TechnicalEmployee {
    ArrayList<SoftwareEngineer> team;
    Accountant support;
    BusinessLead manager;
    Employee bonus;
    int headcount;




    public TechnicalLead(String name) {
        super(name);
        setBaseSalary(getBaseSalary() * 1.3);
        headcount = 4;
        this.team = new ArrayList<SoftwareEngineer>();
    }


    public boolean hasHeadCount() {
        if (team.size() < headcount && team.size() >= 0) {
            return true;
        } else {
            return false;
        }
    }

    public boolean addReport(SoftwareEngineer e) {
        if (hasHeadCount()) {
            team.add(e);
            e.setManager(this);
            return true;
        } else {
            return false;
        }
    }

    public boolean approveCheckIn(SoftwareEngineer e) {

        if (getManager().equals(this) && e.codeAccess) {
            return true;
        } else {
            return true;
        }

    }

    public boolean requestBonus(Employee e, double bonus) {

        support = getAccountantSupport();

        if (this.support.manager.approveBonus(e, bonus)) {
            e.bonus += bonus;
            return true;
        } else {

            return false;//false if otherwise
        }
    }

    public String getTeamStatus() {
        /*Should return a String that gives insight into this Manager and all their
          direct reports. It should return a string that is a combination of the TechnicalLead's
          employee status followed by each of their direct employee's status on subsequent lines.
          If the TechnicalLead has no reports it should print their employee status followed by the text "
          and no direct reports yet ". Example: "10 Kasey has 5 successful check ins and no direct reports yet".*/

        boolean end = false;
        String text1 = this.getId() + " " + this.getName() + "has" + this.checkIns + " successful check ins.";
        if (this.team == null) {
            text1 += "no direct reports yet";
            end = true;
        } else {
            text1 += "is managing: \n" + "---------------------------------------------------------\n";
        }

        if (end != true) {
            for (int i = 0; i < team.size(); i++) {
                int j = i + 1;
                text1 += j + ".Employee ID :   [" + team.get(i).getId() + "] :" + team.get(i).getName() + team.get(i).checkIns + " successful check ins \n";
            }
        }
        return text1;


    }

    public Employee getManager(){return null;}
}
