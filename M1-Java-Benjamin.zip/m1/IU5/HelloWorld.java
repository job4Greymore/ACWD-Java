package com.acwd.m1.IU5;

public class HelloWorld {

    public static void main(String[] args) { //this is a method - group of statements

        System.out.println("Hello World!"); // This is a statement
        // this comment for one line.


    }
}
