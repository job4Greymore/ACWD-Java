package com.acwd.m1.IU5;

public class JavaBasic {
}

/* this is used for comments as many lines as you want */

        /* TESTING CONCEPT
        String mystring = "Konichihello sekworld1";
        System.out.println(mystring);
        mystring = "Sarabyebye";
        System.out.println(mystring);


        double sum = 2.0 * 2.4 + 2.25 * 4.0 / 2.0;
        System.out.println(sum);

        // testing out operations procedure from left to right. -- it works.

         */

        /*
        int x = 123;
        String y = "10";
        //int z = x + y;  -- wont use this statement because using Int cannot achieve String Concatenation
        String z = x + y; // -- Use String instead as String Concatenation requires an int value + a string "text" value
        System.out.println(z);
        y = "";
        //System.out.println(z); -- after changing y value and calling String(z) = value is still 12310 as before.
        String z2 = x + y;
        System.out.println(z2); // -- seems like need to redo process to get new value.
        // Testing out String Concatenation -- it works, i understand. -
        String t = "doe";
        String u = "truce";
        System.out.println(t + u);
        System.out.println(t + " " + u);
        String w = "-doe"; // experimenting with - text(negative text)
        String v = t + u + w;
        System.out.println(v); // as shown here doetruce-doe result does not minus away text.

        //trying out casting

        int a = 10/4;
        double b = 10/4.0;
        int c = (int)(10/4.0);
        double d = (int) 10/4.0;
        System.out.println(a + b + c + d );
        double e = (double)10;
        double f = 10*1.0;
        System.out.println(e + f);
        */ // tested and understood.
