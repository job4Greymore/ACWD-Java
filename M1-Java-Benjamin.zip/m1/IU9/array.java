package com.acwd.m1.IU9;
import java.util.*;
/**
 * Created by $(USER) on $(DATE)
 */
public class array {

    public static void main(String[] args){

        System.out.println("this program calculates your grades");
        System.out.println("enter in your Hw score");

        Scanner input = new Scanner(System.in);
        /*int sum = 0;

        for(int i = 1;  i < 8; i++){
            System.out.println("Hw " + i + " score");
            sum += input.nextInt();
        }
        System.out.println("average score = "  + sum/7 );*/

        int[] arrayInt = new int[10]; // int array
        double[] arrayDouble = new double[10]; // double array
        char [] arrayString = new char[10]; //string array

        //array always reads the first character as n -1

        for(int i = 0;  i < arrayInt.length; i++){
            System.out.println("Hw " + (i+1) + " score: "); // (i+1) is because index of array starts from 0.
            arrayInt[i] += input.nextInt(); // scanning for new input till array Cap Value. in this case is [10].

        }
        int sum = 0;
        for (int i = 0; i < arrayInt.length; i++) {

            sum += arrayInt[i]; // sum

        }
        int avg = sum / arrayInt.length;
        int aboveAvg = 0;
        for (int i = 0; i < arrayInt.length ; i++) {

            if (arrayInt[i]< avg) {

                aboveAvg++;
            }
            
        }
        System.out.println("average score is : " + avg);
        System.out.println(aboveAvg + "hw were above your avg score");


    }


}
