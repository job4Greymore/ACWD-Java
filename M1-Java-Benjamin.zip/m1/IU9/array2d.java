package com.acwd.m1.IU9;

import java.util.*;   //remember to import scanner first.
/**
 * Created by Benjamin on $(DATE)
 */
public class array2d {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        //Datatype[][] name = new type[row][col];
        // e.g int[][] mygrid =  new int [3][5]

        //https://www.youtube.com/watch?time_continue=23&v=CrkVpVoGXvg 1:29 - shows the mechanics for battleship
        // Accessing an element in the 2dArray
        // name [row][col]
        // mygrid[1][3] = 7;

        //2dArray = 2 FOR loops aka nested FOR loop - 2nd For loop within 1st For loop
        //https://www.youtube.com/watch?time_continue=23&v=CrkVpVoGXvg 1:58 - explains nested FOR loop
        // 1st FOR loop is for the rows
        // 2nd For loop is for the columns
        // it should look something like the hardcodes below:



        int count = 0;
        String [][] stringArray = new String[3][3];
        for (int row = 0; row < stringArray.length ; row++) {

            for (int col = 0; col < stringArray.length ; col++) {
                stringArray[row][col] = "["+ row +","+ col +"]";

                String result = stringArray[row][col];
                System.out.println(result);




            }
            
        }


    }
}
