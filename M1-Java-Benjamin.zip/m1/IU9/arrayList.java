package com.acwd.m1.IU9;

import java.util.ArrayList;

/**
 * Created by Benjamin on $(DATE)
 */
public class arrayList {

    public static void main(String[] args) {

        String[] arrayList = new String[5];

        // adding a value
        arrayList[0] = "jessica";
        arrayList[1] = "Dogge";
        System.out.println(arrayList[0] + " has been stored to index [0]");

        //Retrieve and get a value
        String s = arrayList[1]; // means from arraylist get[1] value

        System.out.println("index 1 = " + arrayList[1]);

    }
      /*
      Other functions for ArrayList methods

      add(value)        =   myList.add("hello")
      add(index, value  =   myList.add(0, "hello")
      clear()           =   myList.clear()
      indexOf(value)    =   myList.indexOf("hello")
      get(index)        =   myList.get(0)
      remove(index)     =   myList.remove(0)
      set(index, value) =   myList.set(0, "goodbye")
      size()            =   myList.size()
      toString()        =   myList.toString()
       */

}
