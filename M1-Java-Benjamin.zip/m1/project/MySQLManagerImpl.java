package com.acwd.m1.project;

import java.sql.SQLException;

public class MySQLManagerImpl {

    public static void main(String[] args) {
        MySqlManager mySQLManager = new MySqlManager();
        try {
            mySQLManager.insertCourse();

            //mySQLManager.deleteCompany(1);

            Student student = new Student();
            student.setFirstName("ben");

        }
        catch (SQLException se){
            se.printStackTrace();
        }
        catch (ClassNotFoundException cfe){
            cfe.printStackTrace();
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }
}
