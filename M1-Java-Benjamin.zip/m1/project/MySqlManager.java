package com.acwd.m1.project;

/**
 * This class is to demonstrate
 *  MySQL DB Connection
 *  CRUD operations
 *
 * @author Jeyashree
 * version 1.0
 * @since 2018-12-03
 *
 */

import java.sql.*;
import java.util.ArrayList;


public class MySqlManager {
    /**
     * This method is used to get the database connectivity
     * This method is defined as a private method
     * It is not accessible outside of this class
     *
     * @return java.sql.Connection
     * @throws ClassNotFoundException
     * @throws SQLException
     */
    private Connection getConnection() throws ClassNotFoundException,
            SQLException {
        // Find the class comm.mysql.jdbc.Driver -
        // if the class not found then it throws error
        // ClassNotFoundException

        Class.forName("com.mysql.jdbc.Driver");
        Connection conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/m1project",
                   "root", "");
            //here IU12 is database name, root is username and password
        return conn;
    }

    /**
     * This method inserts the record into company table
     *
     * @return int
     * @throws ClassNotFoundException
     * @throws SQLException
     */
    public int insertCourse() throws ClassNotFoundException,
           SQLException{ // MySQLIntegrityConstraintViolationException

        Connection conn = this.getConnection();
        int rowsInserted = -1;
        String sql ;
        //SQL script to insert record into the company table with the parameter
        // id - Is a auto increment field. It will be inserted automatically
        // CRUD = Create(insert, read , Update, Delete)
        sql = "INSERT INTO coursemaster(course_name, course_text)"+ "VALUES (?,?)";
        // question mark is determined by your number of fields
        PreparedStatement pstmt=conn.prepareStatement(sql);
        //First parameter is the company name of the company entity

        //Second parameter is the city of the company entity
        pstmt.setString(1,"Chicken Nuggets101 "); // first name - Hardcode value cant be change.
        pstmt.setString(2, "Golden Nugget masterclass"); // last name - Hardcode value cant be change.


        //returns the number of records inserted
        rowsInserted =pstmt.executeUpdate();

        return rowsInserted;
    }

    /*public ArrayList<Company> getAllCompanies() throws SQLException, ClassNotFoundException {
        Connection conn = this.getConnection();
        String sql = "SELECT * FROM company";

        Statement stmt=conn.createStatement();
        ResultSet rs=stmt.executeQuery(sql);


        ArrayList<Company> companies = new ArrayList<>();
        Company company =new Company();
        int i=0;
        //Populate the array list from the records of the company table
        while(rs.next()) {
            company =new Company();
            company.setId(rs.getInt("id"));
            company.setCompanyName(rs.getString("Company_name"));
            company.setCity(rs.getString("City"));

            companies.add(company);
        }
        return companies;
    }


    public Company getCompanyById(int id) throws SQLException, ClassNotFoundException {
        Connection conn = this.getConnection();
        String sql = "SELECT * FROM company WHERE id = ?" ;

        PreparedStatement  pstmt = conn.prepareStatement(sql);
        //First parameter is the id of the company entity
        pstmt.setInt(1,id);
        ResultSet rs = pstmt.executeQuery();

        Company company =new Company();
        int i=0;
        //Populate the array list from the records of the company table
        while(rs.next()) {
            company =new Company();
            company.setId(rs.getInt("id"));
            company.setCompanyName(rs.getString("Company_name"));
            company.setCity(rs.getString("City"));
        }
        return company;
    }*/

    public int updateCourse(int course_Id, String courseName, String courseText)
            throws SQLException, ClassNotFoundException {
        Connection conn = this.getConnection();
        String sql = "UPDATE coursemaster " +
                       " SET course_name=?, " +
                           " course_text=? " +
                       " WHERE course id=?";

        PreparedStatement  pstmt = conn.prepareStatement(sql);
        //First parameter is the company name of the company entity
        pstmt.setString(1,courseName);
        //Second parameter is the city of the company entity
        pstmt.setString(2,courseText);
        //Third parameter is the id of the company entity
        pstmt.setInt(3,course_Id);

        int rowsUpdated =  pstmt.executeUpdate();
        return rowsUpdated;
    }

    public int deleteCompany(int id) throws SQLException, ClassNotFoundException {
        Connection conn = this.getConnection();
        String sql = "DELETE FROM coursemaster WHERE course_id =?" ;

        PreparedStatement  pstmt = conn.prepareStatement(sql);
        //First parameter is the id of the company entity
        pstmt.setInt(1,id);

        int rowsDeleted = pstmt.executeUpdate();
        return rowsDeleted;
    }
}
