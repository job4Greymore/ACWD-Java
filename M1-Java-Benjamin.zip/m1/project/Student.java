package com.acwd.m1.project;

import java.sql.*;

public class Student {

    private String firstName;
    private String lastName;
    private String gender;
    private String address;
    private String phone;
    private String course;

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    public boolean isFristNameEqualsLastName(){
        if (this.firstName == this.lastName){ //
            return true;
        }else {
            return false;
        }
    }

    private Connection getConnection() throws ClassNotFoundException,
            SQLException {
        // Find the class comm.mysql.jdbc.Driver -
        // if the class not found then it throws error
        // ClassNotFoundException

        Class.forName("com.mysql.jdbc.Driver");
        Connection conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/m1project",
                "root", "");


        //here IU12 is database name, root is username and password
        return conn;
    }
    public int insertStudent() throws ClassNotFoundException,SQLException{
        int result = -1;
       Connection connection = this.getConnection();

       String queryString;
               queryString = "INSERT INTO `studentmaster`(`Student_FirstName`, " +
               "`Student_LastName`, `Residential_Address`, `Phone_No`, `Course_Id`,`Gender`) " +
               "VALUES (?,?,?,?,?,?)";

               PreparedStatement pstmt = connection.prepareStatement(queryString);

        //PreparedStatement pstmt = connection.prepareStatement(queryString);


       pstmt.setString(1, this.firstName);
       pstmt.setString(2, this.lastName);
       pstmt.setString(3, this.address);
       pstmt.setString(4, this.phone);
       pstmt.setString(5, this.course);
       pstmt.setString(6, this.gender);


        result = pstmt.executeUpdate(); // creating a table value (1x row affected)
        return result;

    }
    /*public ArrayList<Student> getAllStudent() throws ClassNotFoundException,SQLException {
        Connection conn = this.getConnection();
        String sql = "SELECT * FROM studentmaster";

        Statement stmt=conn.createStatement();
        ResultSet rs=stmt.executeQuery(sql); // container that stores all the results.


        ArrayList<Student> students = new ArrayList<>();
        Student student =new Student();
        int i=0;
        //Populate the array list from the records of the company table
        while(rs.next()) {
            Student =new Company();
            company.setId(rs.getInt("id"));
            company.setCompanyName(rs.getString("Company_name"));
            company.setCity(rs.getString("City"));

            companies.add(company);
         return companies;*/
}
