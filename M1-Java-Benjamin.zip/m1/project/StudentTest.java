package com.acwd.m1.project;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.condition.EnabledOnOs;
import org.junit.jupiter.api.condition.OS;

import java.sql.SQLException;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Created by Benjamin on $(DATE)
 *
 * Task 6 (PS3, UK5):
 * 1. Develop unit test cases for testing the function which saves the form to database.
 * 2. Run the unit test case and provide screen capture.
 * 3. Include the Test cases & screen capture as part of Project Presentation.
 */
class StudentTest {
    Student student = new Student();
    @org.junit.jupiter.api.BeforeEach
    void setUp() {
        student.setFirstName("Benjamin");
        student.setLastName("Lee");
        student.setGender("male");
        student.setAddress("singapore");
        student.setPhone("12345678");
        student.setCourse("1");
    }

    @AfterEach
    void tearDow (){
        student = null;
    }
    @org.junit.jupiter.api.Test
    void setPhone() {
        assertEquals("12345678", student.getPhone());
    }

    @org.junit.jupiter.api.Test
    void setFirstName() {
        assertEquals("Benjamin", student.getFirstName());
    }
    @org.junit.jupiter.api.Test
    void setLasttName() {
        assertEquals("Lee", student.getLastName());
    }

    @org.junit.jupiter.api.Test
    void setGender() {
        assertEquals("male", student.getGender());
    }
    @org.junit.jupiter.api.Test
    @EnabledOnOs(OS.LINUX)
    void setAddress() {
        assertEquals("singapore", student.getAddress());
    }
    @org.junit.jupiter.api.Test
    void setphone() {
        assertEquals("12345678", student.getPhone());
    }
    @org.junit.jupiter.api.Test
    void setCourse() {
        assertEquals("1", student.getCourse());
    }
    @org.junit.jupiter.api.Test
    void isFirstNameEqualsLastName() {
        assertFalse(student.isFristNameEqualsLastName());
    }
    @org.junit.jupiter.api.Test
    void insertStudent() {
        try {
            assertEquals(1,student.insertStudent());
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

}