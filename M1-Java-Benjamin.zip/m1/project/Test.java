package com.acwd.m1.project;

import java.sql.SQLException;

/**
 * Created by Benjamin on $(DATE)
 */
public class Test {
    public static void main (String[] args){

        Student student = new Student();

            student.setFirstName("Benjamin");
            student.setLastName("Lee");
            student.setGender("male");
            student.setAddress("singapore");
            student.setPhone("12345678");
            student.setCourse("1");

        try {
            student.insertStudent();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }catch (Exception e){
            e.printStackTrace();
        }

    }
}
