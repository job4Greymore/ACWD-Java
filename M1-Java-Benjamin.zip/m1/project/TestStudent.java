package com.acwd.m1.project;

import java.sql.SQLException;

/**
 * Created by Benjamin on $(DATE)
 */
public class TestStudent {
    public static void main(String[] args) {
        Student s = new Student();
        s.setFirstName("Dandy");
        s.setLastName("Kiss");
        s.setAddress("singapore 123123");
        s.setPhone("12345678");


        try {
            s.insertStudent();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }
}
